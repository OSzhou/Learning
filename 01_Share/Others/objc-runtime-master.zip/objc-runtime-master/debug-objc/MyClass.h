//
//  MyClass.h
//  debug-objc
//
//  Created by zhangliang on 2019/3/13.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface MyClass : NSError {
    @public
    int myInt;
}

@end

@interface MyClass (Zhiliang)

@property (nonatomic, copy) NSString *zhiliangString;

- (void)zhiliang729Error;

@end

NS_ASSUME_NONNULL_END
