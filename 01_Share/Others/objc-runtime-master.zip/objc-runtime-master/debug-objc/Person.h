//
//  Person.h
//  debug-objc
//
//  Created by zhangliang on 2019/3/11.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

enum FooManChu {
    FOO,
    MAN,
    CHU
};

struct YorkshireTeaStruct {
    int pot;
    char lady;
};

typedef struct YorkshireTeaStruct YorkshireTeaStructType;

union MoneyUnion {
    float alone;
    double down;
};

@interface Person : NSObject

@property char charDefault; //Tc,VcharDefault

@property double doubleDefault; // Td,VdoubleDefault

@property enum FooManChu enumDefault; // Ti,VenumDefault

@property float floatDefault; // Tf,VfloatDefault

@property int intDefault; // Ti,VintDefault

@property long longDefault; // Tl,VlongDefault

@property short shortDefault; // Ts,VshortDefault

@property signed signedDefault; // Ti,VsignedDefault

@property struct YorkshireTeaStruct structDefault; // T{YorkshireTeaStruct="pot"i"lady"c},VstructDefault

@property YorkshireTeaStructType typedefDefault; // T{YorkshireTeaStruct="pot"i"lady"c},VtypedefDefault

@property union MoneyUnion unionDefault; // T(MoneyUnion="alone"f"down"d),VunionDefault

@property unsigned unsignedDefault; // TI,VunsignedDefault

@property int (*functionPointerDefault)(char *); // T^?,VfunctionPointerDefault

@property id idDefault; /// Note: the compiler warns: "no 'assign', 'retain', or 'copy' attribute is specified - 'assign' is assumed" // T@,VidDefault

@property int *intPointer; // T^i,VintPointer

@property void *voidPointerDefault; // T^v,VvoidPointerDefault

@property int intSynthEquals; /// In the implementation block: @synthesize intSynthEquals=_intSynthEquals; // Ti,V_intSynthEquals

@property(getter=intGetFoo, setter=intSetFoo:) int intSetterGetter; // Ti,GintGetFoo,SintSetFoo:,VintSetterGetter

@property(readonly) int intReadonly; // Ti,R,VintReadonly

@property(getter=isIntReadOnlyGetter, readonly) int intReadonlyGetter; // Ti,R,GisIntReadOnlyGetter

@property(readwrite) int intReadwrite; // Ti,VintReadwrite

@property(assign) int intAssign; // Ti,VintAssign

@property(retain) id idRetain; // T@,&,VidRetain

@property(copy) id idCopy; // T@,C,VidCopy

@property(nonatomic) int intNonatomic; // Ti,VintNonatomic

@property(nonatomic, readonly, copy) id idReadonlyCopyNonatomic; // T@,R,C,VidReadonlyCopyNonatomic

@property(nonatomic, readonly, retain) id idReadonlyRetainNonatomic; // T@,R,&,VidReadonlyRetainNonatomic

@property (nonatomic, assign) SEL cfunc;

- (int)add:(int)val;

@end

NS_ASSUME_NONNULL_END
