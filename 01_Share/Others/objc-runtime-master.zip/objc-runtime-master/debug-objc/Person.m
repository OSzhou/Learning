//
//  Person.m
//  debug-objc
//
//  Created by zhangliang on 2019/3/11.
//

#import "Person.h"
#import <objc/runtime.h>

@implementation Person
@synthesize intSynthEquals=_intSynthEquals;

void myClassImp(id _rec, SEL _cmd, NSNumber *theInt) {
    NSLog(@"dynamic added method: %d", theInt.intValue);
}

- (instancetype)init
{
    self = [super init];
    if (self) {
        self.cfunc = @selector(add:);
        class_addMethod([Person class], @selector(dynGeneratedMethod:), (IMP)myClassImp, "v@:i");
    }
    return self;
}

- (int)add:(int)val {
    return val;
}

@end
