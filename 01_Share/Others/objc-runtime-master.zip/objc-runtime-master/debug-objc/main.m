//
//  main.m
//  debug-objc
//
//  Created by Closure on 2018/12/4.
//

#import <Foundation/Foundation.h>
#import <objc/runtime.h>
#import "Person.h"
#import "MyClass.h"

int test(int val) {
    return val + 1;
}

int (*c_func)(int val);

void logPersonProperties() {
    id PersonClass = objc_getClass("Person");
    unsigned int outCount, i;

    objc_property_t *properties = class_copyPropertyList(PersonClass, &outCount);
    for (i = 0; i < outCount; i++) {
        objc_property_t property = properties[i];
        fprintf(stdout, "%s %s\n", property_getName(property), property_getAttributes(property));
    }
}

#define Hello @"helloowe"
int main(int argc, const char * argv[]) {
    @autoreleasepool {
        // insert code here...
        //        c_func = test;
        //        NSLog(@"value: %d", c_func(32));
        //
        //        Person *p = [[Person alloc] init];
        //        [p performSelector:p.cfunc];
        //
        //        [p performSelector:@selector(dynGeneratedMethod:) withObject:@1];
        //
        //        NSString *string = @"hello";
        //        string = [string stringByAppendingString:@" world!"];
        //        NSLog(@"---------%@", string);

        MyClass *cls = [[MyClass alloc] init]; 
        NSObject *objc;
        @autoreleasepool {
            cls->myInt = 42;
            objc = [[NSObject alloc] init];
        }


        NSLog(@"%@", objc);
        NSLog(@"%@", @"dd");
        NSLog(@"%@", @"dd");
        NSLog(@"%@", @"bb");
        NSLog(@"hello: %@", Hello);

        logPersonProperties();

    }
    return 0;
}
