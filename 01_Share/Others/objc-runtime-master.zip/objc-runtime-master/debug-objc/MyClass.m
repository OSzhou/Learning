//
//  MyClass.m
//  debug-objc
//
//  Created by zhangliang on 2019/3/13.
//

#import "MyClass.h"

@implementation MyClass

+ (void)load {
    NSLog(@"MyClass Load");
}

@end

@implementation MyClass (Zhiliang)

- (void)zhiliang729Error {
    
}

@end
