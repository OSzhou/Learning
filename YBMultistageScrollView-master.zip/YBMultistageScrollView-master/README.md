# YBMultistageScrollView

多个scrollview联动的最优解决方案

<img src="https://github.com/indulgeIn/YBMultistageScrollView/blob/master/YBMultistageScrollViewFiles/Untitled.gif">

详细介绍见简书地址：http://www.jianshu.com/p/42479a0e8ac6
