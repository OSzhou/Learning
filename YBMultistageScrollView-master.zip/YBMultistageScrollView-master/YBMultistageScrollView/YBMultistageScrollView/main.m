//
//  main.m
//  YBMultistageScrollView
//
//  Created by cqdingwei@163.com on 2017/5/27.
//  Copyright © 2017年 yangbo. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
