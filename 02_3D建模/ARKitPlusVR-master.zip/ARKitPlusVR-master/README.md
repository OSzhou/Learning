# ARKitPlusVR

VR with SceneKit &amp; ARKit. 
This project demonstrates the using of ARKit to make the movement in VR scene possible.

## Requirements

* A9 ( iPhone 6S or later )
* Xcode 9 Beta 2
* iOS 11

## More Details

http://www.jianshu.com/p/4f9809021142

## GIF

![image](https://github.com/WorkerAmo/ARKitPlusVR/blob/master/demo00.gif)

![image](https://github.com/WorkerAmo/ARKitPlusVR/blob/master/demo02.gif)

![image](https://github.com/WorkerAmo/ARKitPlusVR/blob/master/demo01.gif)



