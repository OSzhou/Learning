//
//  AppDelegate.h
//  ARVRCombine
//
//  Created by workeramo on 2017/7/25.
//  Copyright © 2017年 Solar. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

