//
//  main.m
//  ARVRCombine
//
//  Created by workeramo on 2017/7/25.
//  Copyright © 2017年 Solar. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
