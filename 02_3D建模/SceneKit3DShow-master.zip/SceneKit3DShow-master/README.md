# SceneKitShose
#### 用CollectionView 定义卡片式预览界面
 ![images](http://ois78ab8t.bkt.clouddn.com/shose3.png)
#### 用SceneKit加载鞋子的3D模型，可以旋转查看鞋子的详细样式
 ![images](http://ois78ab8t.bkt.clouddn.com/shose2.png)
#### 自定义鞋子的表面材质
 ![images](http://ois78ab8t.bkt.clouddn.com/shose1.png)
