//
//  main.m
//  EPOQUEShose
//
//  Created by EPOQUE on 01/04/2017.
//  Copyright © 2017 JalynnXi. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
