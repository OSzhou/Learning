//
//  customeShoseViewController.h
//  EPOQUEShose
//
//  Created by EPOQUE on 07/04/2017.
//  Copyright © 2017 JalynnXi. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface customeShoseViewController : UIViewController

@end
