//
//  ShowboardCollectionViewCell.m
//  EPOQUEShose
//
//  Created by EPOQUE on 07/04/2017.
//  Copyright © 2017 JalynnXi. All rights reserved.
//

#import "ShowboardCollectionViewCell.h"

@implementation ShowboardCollectionViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

@end
