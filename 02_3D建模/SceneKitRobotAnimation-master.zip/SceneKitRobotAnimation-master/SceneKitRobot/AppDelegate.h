//
//  AppDelegate.h
//  SceneKitRobot
//
//  Created by JalynnXi on 29/03/2017.
//  Copyright © 2017 JalynnXi. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

