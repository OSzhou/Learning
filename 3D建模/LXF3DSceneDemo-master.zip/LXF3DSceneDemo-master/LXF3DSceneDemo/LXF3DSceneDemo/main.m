//
//  main.m
//  LXF3DSceneDemo
//
//  Created by 林洵锋 on 2017/6/30.
//  Copyright © 2017年 LXF. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
