# LXF3DSceneDemo
SceneKit的使用Demo

## 简书
[iOS - SceneKit显示与交互3D建模（一）](http://www.jianshu.com/p/df7514a6cb91)
[iOS - SceneKit显示与交互3D建模（二）](http://www.jianshu.com/p/78be2688ef4c)

## 效果图
![image](https://github.com/LinXunFeng/LXF3DSceneDemo/raw/master/Screenshots/demo.gif)


