//
//  CATUsedClass.h
//  TestUnUsedClassesProject
//
//  Created by CatchZeng on 15/12/28.
//  Copyright © 2015年 catch. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface CATUsedClass : NSObject

@end
