# CATClearProjectTool
clear objective-c project unused class file

----------
中文请[戳这里](http://catchzeng.com/2016/01/23/iOS%E6%B8%85%E7%90%86%E5%B7%A5%E7%A8%8B%E4%B8%AD%E6%9C%AA%E4%BD%BF%E7%94%A8%E7%9A%84%E7%B1%BB%E6%96%87%E4%BB%B6%E5%B7%A5%E5%85%B7/) ； 简书好友请[戳这里](http://www.jianshu.com/p/1b188a91b23f)；

***Please backup before use it!***
----------------


1.TestUnUsedClassesProject structure

![TestUnUsedClassesProject](https://github.com/CatchZeng/CATClearProjectTool/blob/master/images/0.png)


2.drag TestUnUsedClassesProject.xcodeproj to CATClearProjectTool then click search button.

![TestUnUsedClassesProject](https://github.com/CatchZeng/CATClearProjectTool/blob/master/images/1.png)


3.search result

![TestUnUsedClassesProject](https://github.com/CatchZeng/CATClearProjectTool/blob/master/images/2.png)


4.click clear button.

![TestUnUsedClassesProject](https://github.com/CatchZeng/CATClearProjectTool/blob/master/images/3.png)


5.see TestUnUsedClassesProject structure now.

![TestUnUsedClassesProject](https://github.com/CatchZeng/CATClearProjectTool/blob/master/images/4.png)


you also can add fliter like this.

![TestUnUsedClassesProject](https://github.com/CatchZeng/CATClearProjectTool/blob/master/images/5.png)


clear result

![TestUnUsedClassesProject](https://github.com/CatchZeng/CATClearProjectTool/blob/master/images/6.png)


TestUnUsedClassesProject structure

![TestUnUsedClassesProject](https://github.com/CatchZeng/CATClearProjectTool/blob/master/images/7.png)
