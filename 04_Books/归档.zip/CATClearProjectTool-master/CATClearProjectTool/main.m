//
//  main.m
//  CATClearProjectTool
//
//  Created by CatchZeng on 15/12/29.
//  Copyright © 2015年 catch. All rights reserved.
//

#import <Cocoa/Cocoa.h>

int main(int argc, const char * argv[]) {
    return NSApplicationMain(argc, argv);
}
