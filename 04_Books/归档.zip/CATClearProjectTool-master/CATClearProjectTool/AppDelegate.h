//
//  AppDelegate.h
//  CATClearProjectTool
//
//  Created by CatchZeng on 15/12/29.
//  Copyright © 2015年 catch. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@interface AppDelegate : NSObject <NSApplicationDelegate>


@end

